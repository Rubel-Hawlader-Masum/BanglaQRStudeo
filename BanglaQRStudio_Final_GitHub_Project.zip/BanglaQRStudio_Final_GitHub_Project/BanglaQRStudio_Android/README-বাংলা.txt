Bangla QR Studio — GitHub Build Project
======================================

কাজের অবস্থা
------------
এই ZIP-এ Android প্রজেক্ট, GitHub Actions workflow এবং Gradle চালানোর স্ক্রিপ্ট রয়েছে।
এই পরিবেশে Android SDK/Gradle build চালিয়ে APK তৈরি করে পরীক্ষা করা হয়নি। তাই APK সফল হবে বলে নিশ্চয়তা দেওয়া হচ্ছে না।

GitHub থেকে APK তৈরি
--------------------
1. ZIP Extract করুন।
2. ZIP-এর ভেতরের `BanglaQRStudio_Android` ফোল্ডারের CONTENTS আপনার GitHub repository-র root-এ আপলোড করুন। ফোল্ডারটিকে আরেকটি nested folder হিসেবে আপলোড করবেন না।
3. GitHub repository-তে Actions সক্রিয় করুন।
4. `Actions` > `Android APK Build` > `Run workflow` চাপুন, অথবা `main`/`master` branch-এ push করুন।
5. Workflow সফল হলে run খুলে `Artifacts` থেকে `BanglaQRStudio-debug-apk` ডাউনলোড করুন।

স্থানীয় Build
-------------
প্রয়োজন: JDK 17, Android SDK Platform 35, Android Build Tools 35.0.0, ইন্টারনেট।
Linux/macOS: `./gradlew assembleDebug`
Windows: `gradlew.bat assembleDebug`

নোট: এই প্রজেক্টের gradlew/gradlew.bat Gradle 8.7 distribution ডাউনলোড করে চালানোর lightweight launcher; এটি প্রচলিত Gradle Wrapper JAR-ভিত্তিক wrapper নয়। GitHub workflow Gradle 8.7 সরাসরি সেটআপ করে, তাই build-এর জন্য wrapper JAR দরকার হয় না।

সুরক্ষা ও অনুমতি
---------------
মূল `app/src/main/res/drawable/logo.jpg` ফাইলটি অপরিবর্তিত রাখা হয়েছে। মূল Manifest-এর অনুমতি এবং UI-র বৈশিষ্ট্যগুলো অডিট করে পুনরায় নিশ্চিত করা প্রয়োজন; এখানে মূল Manifest-কে অকারণে প্রতিস্থাপন করা হয়নি। Camera/WebView permission flow ও scanner runtime behavior অবশ্যই বাস্তব ডিভাইসে পরীক্ষা করুন।

APK ইনস্টল
----------
Debug APK ডাউনলোড করে ফোনে খুলুন। Android চাইলে আপনার ব্রাউজার/ফাইল ম্যানেজারের জন্য “Install unknown apps” অনুমতি দিন। শুধুমাত্র নিজের তৈরি/বিশ্বস্ত APK ইনস্টল করুন।
