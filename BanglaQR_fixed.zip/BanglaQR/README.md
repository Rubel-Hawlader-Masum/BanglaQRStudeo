# Bangla QR Premium

Bangla QR Premium একটি offline Android QR ও barcode generator/scanner অ্যাপ। QR তৈরি, barcode তৈরি, camera scan, gallery scan এবং PNG save—সবকিছু অ্যাপের local assets দিয়ে চলে।

## GitHub দিয়ে APK বানানো

1. এই ZIP extract করে ভেতরের `BanglaQR` folder-এর সব ফাইল একটি নতুন GitHub repository-র root-এ upload করুন।
2. **Actions** tab-এ গিয়ে `Build APK` workflow চালু করুন।
3. `main` বা `master` branch-এ push করলে workflow নিজে চলবে।
4. সফল হলে Actions run-এর **Artifacts** অংশ থেকে `BanglaQR-APK` download করুন।

Workflow-এর প্রয়োজনীয় JavaScript libraries ZIP-এর ভেতরেই রাখা আছে; build চলার সময় কোনো CDN থেকে library download বা source file পরিবর্তন করা হয় না।

## Release update-এর জন্য স্থায়ী signing key

প্রথম build-এর আগে persistent signing key configure করলে ভবিষ্যতের APK update হিসেবে install করা যাবে। না করলে workflow নিজে temporary CI key বানিয়ে APK তৈরি করবে; সেটি test build-এর জন্য ঠিক আছে, কিন্তু পরের build দিয়ে পুরোনো APK update করা যাবে না।

Local machine-এ একবার keystore বানান:

```bash
keytool -genkeypair -v \
  -keystore banglaqr-release.jks \
  -alias banglaqr \
  -keyalg RSA -keysize 2048 -validity 10000
base64 -w 0 banglaqr-release.jks > banglaqr-release.jks.base64
```

GitHub repository-এর **Settings → Secrets and variables → Actions**-এ এই চারটি **Repository secrets** যোগ করুন:

- `SIGNING_KEYSTORE_BASE64`: `banglaqr-release.jks.base64` ফাইলের সম্পূর্ণ এক লাইনের content
- `SIGNING_STORE_PASSWORD`: keystore password
- `SIGNING_KEY_ALIAS`: সাধারণত `banglaqr`
- `SIGNING_KEY_PASSWORD`: key password

Keystore এবং password কখনো repository-তে commit করবেন না। হারিয়ে গেলে একই package name-এর নতুন signing key দিয়ে পুরোনো APK update করা যাবে না—তাই encrypted backup রাখুন।

## গুরুত্বপূর্ণ security note

Premium token ব্যবস্থা offline device-code ভিত্তিক। Android APK-এর ভেতরের যেকোনো client-side PIN বা licensing logic দক্ষ reverse engineering-এর মাধ্যমে পরিবর্তন করা সম্ভব। তাই এটি offline convenience licensing হিসেবে ব্যবহার করুন; high-value paid licensing-এর জন্য server-side verification প্রয়োজন।

## Build requirements

- Android Gradle Plugin 8.6.1
- Gradle wrapper 8.7
- Java 17
- compileSdk 34
- minSdk 24
