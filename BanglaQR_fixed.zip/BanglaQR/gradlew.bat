@echo off
setlocal
set "GRADLE_VERSION=8.7"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "DIST_DIR=%GRADLE_USER_HOME%\manual-wrapper\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%DIST_DIR%\bin\gradle.bat"
if exist "%GRADLE_BIN%" goto run_gradle
if not exist "%GRADLE_USER_HOME%\manual-wrapper" mkdir "%GRADLE_USER_HOME%\manual-wrapper"
set "ZIP=%GRADLE_USER_HOME%\manual-wrapper\gradle-%GRADLE_VERSION%-bin.zip"
if not exist "%ZIP%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  if errorlevel 1 exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%GRADLE_USER_HOME%\manual-wrapper'"
if errorlevel 1 exit /b 1
:run_gradle
call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
