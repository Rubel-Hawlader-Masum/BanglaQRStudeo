-keepattributes *Annotation*,JavascriptInterface,InnerClasses,EnclosingMethod
-keep class com.banglaqr.premium.MainActivity$Bridge { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.google.zxing.** { *; }
-dontwarn com.google.zxing.**
