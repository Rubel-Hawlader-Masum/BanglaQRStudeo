Bangla QR Studio — Android অ্যাপের প্রাথমিক প্রজেক্ট

গুরুত্বপূর্ণ:
- এটি APK নয়; Android Studio দিয়ে APK বানানোর জন্য সোর্স প্রজেক্ট।
- QR কোড তৈরির লাইব্রেরি প্রথমবার লোড করতে ইন্টারনেট লাগবে।
- QR ইতিহাস WebView-এর local storage-এ এই ফোনেই থাকে।
- PNG/SVG ডাউনলোড Android WebView-এ সব ডিভাইসে একইভাবে কাজ নাও করতে পারে; পরীক্ষা ও পরবর্তী সংশোধন দরকার।
- APK তৈরি করতে Windows 10 কম্পিউটারে Android Studio ও Android SDK ইনস্টল করতে হবে।
- কোনো পাসওয়ার্ড, ব্যাংক তথ্য বা গোপন তথ্য এই পরীক্ষামূলক সংস্করণে রাখবেন না।

প্রজেক্ট খুলতে:
1. ZIP ফাইল Extract করুন।
2. Android Studio খুলুন।
3. Open নির্বাচন করে BanglaQRStudio ফোল্ডারটি বাছুন।
4. Gradle sync সম্পন্ন হতে দিন।
5. Build > Build APK(s) নির্বাচন করুন।
6. তৈরি APK সাধারণত app/build/outputs/apk/debug/app-debug.apk পথে থাকবে।

নোট: Android Studio/Gradle-এর সংস্করণ ও নেটওয়ার্কের কারণে বিল্ডে অতিরিক্ত ধাপ লাগতে পারে।
