package com.banglaqr.premium;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.common.GlobalHistogramBinarizer;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.pdf417.PDF417Writer;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {

    // ★ বদলান: এটা আপনার অ্যাডমিন পিন। নিজের গোপন পিন দিন।
    private static final String ADMIN_PIN = "786543";

    private static final int REQ_FILE = 11, REQ_PERM = 12, REQ_SCAN = 13;

    private WebView web;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> filePathCb;
    private PermissionRequest pendingPerm;

    // ★ বদলান: গোপন চাবি। নিজের মতো লম্বা অন্য লেখা দিন। কাউকে দেখাবেন না।
    private String secret() {
        return "Bq" + (7 * 13) + "#xK9vLm" + (char) 70 + "2026qR!" + "zT4" + (3 * 11);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("bq_core", MODE_PRIVATE);
        askPerms();

        web = new WebView(this);
        setContentView(web);
        web.setBackgroundColor(0xFF0A0E1A);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBlockNetworkLoads(true); // ১০০% অফলাইন

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return true; // বাইরের লিংকে যাওয়া বন্ধ
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        r.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        pendingPerm = r;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_PERM);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCb != null) filePathCb.onReceiveValue(null);
                filePathCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "ছবি বাছাই করুন"), REQ_FILE);
                } catch (Exception e) {
                    filePathCb = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void askPerms() {
        List<String> l = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            l.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            l.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (!l.isEmpty()) requestPermissions(l.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (pendingPerm != null) {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                pendingPerm.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else pendingPerm.deny();
            pendingPerm = null;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SCAN) {
            if (res == RESULT_OK && data != null && data.getData() != null) {
                final Uri u = data.getData();
                new Thread(() -> {
                    String r = decodeUri(u);
                    final String js = "window.onNativeScan&&window.onNativeScan(" + JSONObject.quote(r == null ? "" : r) + ")";
                    runOnUiThread(() -> web.evaluateJavascript(js, null));
                }).start();
            }
            return;
        }
        if (req == REQ_FILE && filePathCb != null) {
            Uri[] r = (res == RESULT_OK && data != null && data.getData() != null)
                    ? new Uri[]{data.getData()} : null;
            filePathCb.onReceiveValue(r);
            filePathCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.goBack?window.goBack():false", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("Android");
            web.destroy();
        }
        super.onDestroy();
    }

    // ---------- সিকিউরিটি হেল্পার ----------

    private String hmac(String msg) {
        try {
            Mac m = Mac.getInstance("HmacSHA256");
            m.init(new SecretKeySpec(secret().getBytes("UTF-8"), "HmacSHA256"));
            byte[] d = m.doFinal(msg.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 6; i++) sb.append(String.format("%02X", d[i] & 0xff));
            String h = sb.toString();
            return h.substring(0, 4) + "-" + h.substring(4, 8) + "-" + h.substring(8, 12);
        } catch (Exception e) {
            return "";
        }
    }

    private String norm(String s) {
        return s == null ? "" : s.replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT);
    }

    private boolean same(String a, String b) {
        try {
            return MessageDigest.isEqual(a.getBytes("UTF-8"), b.getBytes("UTF-8"));
        } catch (Exception e) {
            return false;
        }
    }

    private String devId() {
        String id = null;
        try {
            id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Exception ignored) {
        }
        if (id == null || id.length() < 8) {
            id = prefs.getString("did", null);
            if (id == null) {
                id = UUID.randomUUID().toString().replace("-", "");
                prefs.edit().putString("did", id).apply();
            }
        }
        return id.substring(0, 8).toUpperCase(Locale.ROOT);
    }

    private String tokenFor(String dev, String l4) {
        return hmac(norm(dev) + "|" + l4);
    }

    private long lockLeft(String key) {
        long l = (prefs.getLong(key + "_u", 0) - System.currentTimeMillis()) / 1000;
        return l > 0 ? l : 0;
    }

    private void fail(String key) {
        int c = prefs.getInt(key + "_c", 0) + 1;
        SharedPreferences.Editor e = prefs.edit();
        if (c >= 5) {
            e.putLong(key + "_u", System.currentTimeMillis() + 60000L);
            c = 0;
        }
        e.putInt(key + "_c", c).apply();
    }

    // ---------- গ্যালারির ছবি থেকে QR পড়া (ZXing, মেমরি-নিরাপদ) ----------

    private Bitmap loadBitmap(Uri uri, int sample) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                return BitmapFactory.decodeStream(in, null, o);
            }
        } catch (Throwable t) {
            return null;
        }
    }

    private String tryBitmap(Bitmap b) {
        try {
            int w = b.getWidth(), h = b.getHeight();
            int[] px = new int[w * h];
            b.getPixels(px, 0, w, 0, 0, w, h);
            LuminanceSource src = new RGBLuminanceSource(w, h, px);
            Map<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);
            hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
            hints.put(DecodeHintType.POSSIBLE_FORMATS, Arrays.asList(BarcodeFormat.QR_CODE, BarcodeFormat.PDF_417,
                    BarcodeFormat.CODE_128, BarcodeFormat.CODE_39, BarcodeFormat.EAN_13, BarcodeFormat.EAN_8,
                    BarcodeFormat.UPC_A, BarcodeFormat.ITF));
            hints.put(DecodeHintType.CHARACTER_SET, "UTF-8");
            LuminanceSource[] list = {src, src.invert()};
            for (LuminanceSource ls : list) {
                for (int k = 0; k < 2; k++) {
                    try {
                        BinaryBitmap bb = new BinaryBitmap(k == 0 ? new HybridBinarizer(ls) : new GlobalHistogramBinarizer(ls));
                        return new MultiFormatReader().decode(bb, hints).getText();
                    } catch (Exception ignored) {
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private String tryTiles(Bitmap bm) {
        int w = bm.getWidth(), h = bm.getHeight();
        int tw = Math.min(w, 1100), th = Math.min(h, 1100);
        for (int y = 0; y < h; y += Math.max(1, th / 2)) {
            for (int x = 0; x < w; x += Math.max(1, tw / 2)) {
                int cw = Math.min(tw, w - x), ch = Math.min(th, h - y);
                if (cw < 100 || ch < 100) continue;
                try {
                    Bitmap c = Bitmap.createBitmap(bm, x, y, cw, ch);
                    String r = tryBitmap(c);
                    if (r == null) {
                        Bitmap u = Bitmap.createScaledBitmap(c, cw * 2, ch * 2, true);
                        r = tryBitmap(u);
                        u.recycle();
                    }
                    if (c != bm) c.recycle();
                    if (r != null) return r;
                } catch (Throwable ignored) {
                }
            }
        }
        return null;
    }

    private String decodeUri(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int max = Math.max(o.outWidth, o.outHeight);
            if (max <= 0) return null;
            int s0 = 1;
            while (max / s0 > 3200) s0 *= 2;
            for (int s = s0; s <= s0 * 4 && max / s >= 300; s *= 2) {
                Bitmap bm = loadBitmap(uri, s);
                if (bm == null) continue;
                String r = tryBitmap(bm);
                if (r == null && s == s0) r = tryTiles(bm);
                bm.recycle();
                if (r != null) return r;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    // ---------- JavaScript ব্রিজ ----------

    private class Bridge {

        @JavascriptInterface
        public String deviceId() {
            return devId();
        }

        @JavascriptInterface
        public boolean isPremium() {
            String tk = prefs.getString("tk", "");
            String l4 = prefs.getString("l4", "");
            if (tk.isEmpty() || l4.isEmpty()) return false;
            return same(norm(tk), norm(tokenFor(devId(), l4)));
        }

        @JavascriptInterface
        public String activate(String l4, String token) {
            long w = lockLeft("act");
            if (w > 0) return "LOCKED:" + w;
            if (l4 == null || !l4.matches("\\d{4}")) return "BAD";
            if (same(norm(token), norm(tokenFor(devId(), l4)))) {
                prefs.edit().putString("l4", l4).putString("tk", norm(token)).apply();
                return "OK";
            }
            fail("act");
            return "BAD";
        }

        @JavascriptInterface
        public boolean adminCheck(String pin) {
            return pin != null && same(pin, ADMIN_PIN);
        }

        @JavascriptInterface
        public String makeToken(String pin, String l4, String dev) {
            long w = lockLeft("adm");
            if (w > 0) return "LOCKED:" + w;
            if (pin == null || !same(pin, ADMIN_PIN)) {
                fail("adm");
                return "ERR:PIN";
            }
            if (l4 == null || !l4.matches("\\d{4}")) return "ERR:L4";
            if (norm(dev).length() < 8) return "ERR:DEV";
            return "TOKEN:" + tokenFor(dev, l4);
        }

        @JavascriptInterface
        public String saveImage(String dataUrl, String name) {
            try {
                String b64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                name = name.replaceAll("[^A-Za-z0-9._-]", "_");
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (u == null) return "ERR";
                    try (OutputStream os = getContentResolver().openOutputStream(u)) {
                        os.write(bytes);
                    }
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    dir.mkdirs();
                    File f = new File(dir, name);
                    try (FileOutputStream os = new FileOutputStream(f)) {
                        os.write(bytes);
                    }
                    sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(f)));
                }
                return "OK";
            } catch (Throwable t) {
                return "ERR";
            }
        }

        @JavascriptInterface
        public String pdf417(String text) {
            try {
                if (text == null || text.trim().isEmpty() || text.length() > 1500) return "ERR";
                Map<EncodeHintType, Object> h = new EnumMap<>(EncodeHintType.class);
                h.put(EncodeHintType.CHARACTER_SET, "UTF-8");
                h.put(EncodeHintType.MARGIN, 12);
                h.put(EncodeHintType.ERROR_CORRECTION, 4);
                BitMatrix m = new PDF417Writer().encode(text, BarcodeFormat.PDF_417, 900, 300, h);
                int w = m.getWidth(), ht = m.getHeight();
                int[] px = new int[w * ht];
                for (int y = 0; y < ht; y++)
                    for (int x = 0; x < w; x++)
                        px[y * w + x] = m.get(x, y) ? 0xFF000000 : 0xFFFFFFFF;
                Bitmap bmp = Bitmap.createBitmap(px, w, ht, Bitmap.Config.ARGB_8888);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.PNG, 100, bo);
                bmp.recycle();
                return "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
            } catch (Throwable t) {
                return "ERR";
            }
        }

        @JavascriptInterface
        public void pickAndScan() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "ছবি বাছাই করুন"), REQ_SCAN);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("bq", text));
            });
        }

        @JavascriptInterface
        public void openLink(final String url) {
            if (url == null || !url.matches("(?i)^https?://.+")) return;
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "লিংক খোলা যায়নি", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
