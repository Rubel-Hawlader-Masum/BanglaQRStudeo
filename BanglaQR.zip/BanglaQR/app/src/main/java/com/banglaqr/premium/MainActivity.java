package com.banglaqr.premium;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {

    // ★ বদলান: এটা আপনার অ্যাডমিন পিন। নিজের গোপন পিন দিন।
    private static final String ADMIN_PIN = "786543";

    private static final int REQ_FILE = 11, REQ_PERM = 12;

    private WebView web;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> filePathCb;
    private PermissionRequest pendingPerm;

    // ★ বদলান: গোপন চাবি। নিজের মতো লম্বা অন্য লেখা দিন। কাউকে দেখাবেন না।
    private String secret() {
        return "Bq" + (7 * 13) + "#xK9vLm" + (char) 70 + "2026qR!" + "zT4" + (3 * 11);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("bq_core", MODE_PRIVATE);
        askPerms();

        web = new WebView(this);
        setContentView(web);
        web.setBackgroundColor(0xFF0A0E1A);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBlockNetworkLoads(true); // ১০০% অফলাইন

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return true; // বাইরের লিংকে যাওয়া বন্ধ
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        r.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        pendingPerm = r;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_PERM);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCb != null) filePathCb.onReceiveValue(null);
                filePathCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "ছবি বাছাই করুন"), REQ_FILE);
                } catch (Exception e) {
                    filePathCb = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void askPerms() {
        List<String> l = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            l.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            l.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (!l.isEmpty()) requestPermissions(l.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (pendingPerm != null) {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                pendingPerm.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else pendingPerm.deny();
            pendingPerm = null;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && filePathCb != null) {
            Uri[] r = (res == RESULT_OK && data != null && data.getData() != null)
                    ? new Uri[]{data.getData()} : null;
            filePathCb.onReceiveValue(r);
            filePathCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.goBack?window.goBack():false", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("Android");
            web.destroy();
        }
        super.onDestroy();
    }

    // ---------- সিকিউরিটি হেল্পার ----------

    private String hmac(String msg) {
        try {
            Mac m = Mac.getInstance("HmacSHA256");
            m.init(new SecretKeySpec(secret().getBytes("UTF-8"), "HmacSHA256"));
            byte[] d = m.doFinal(msg.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 6; i++) sb.append(String.format("%02X", d[i] & 0xff));
            String h = sb.toString();
            return h.substring(0, 4) + "-" + h.substring(4, 8) + "-" + h.substring(8, 12);
        } catch (Exception e) {
            return "";
        }
    }

    private String norm(String s) {
        return s == null ? "" : s.replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT);
    }

    private boolean same(String a, String b) {
        try {
            return MessageDigest.isEqual(a.getBytes("UTF-8"), b.getBytes("UTF-8"));
        } catch (Exception e) {
            return false;
        }
    }

    private String devId() {
        String id = null;
        try {
            id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Exception ignored) {
        }
        if (id == null || id.length() < 8) {
            id = prefs.getString("did", null);
            if (id == null) {
                id = UUID.randomUUID().toString().replace("-", "");
                prefs.edit().putString("did", id).apply();
            }
        }
        return id.substring(0, 8).toUpperCase(Locale.ROOT);
    }

    private String tokenFor(String dev, String l4) {
        return hmac(norm(dev) + "|" + l4);
    }

    private long lockLeft(String key) {
        long l = (prefs.getLong(key + "_u", 0) - System.currentTimeMillis()) / 1000;
        return l > 0 ? l : 0;
    }

    private void fail(String key) {
        int c = prefs.getInt(key + "_c", 0) + 1;
        SharedPreferences.Editor e = prefs.edit();
        if (c >= 5) {
            e.putLong(key + "_u", System.currentTimeMillis() + 60000L);
            c = 0;
        }
        e.putInt(key + "_c", c).apply();
    }

    // ---------- JavaScript ব্রিজ ----------

    private class Bridge {

        @JavascriptInterface
        public String deviceId() {
            return devId();
        }

        @JavascriptInterface
        public boolean isPremium() {
            String tk = prefs.getString("tk", "");
            String l4 = prefs.getString("l4", "");
            if (tk.isEmpty() || l4.isEmpty()) return false;
            return same(norm(tk), norm(tokenFor(devId(), l4)));
        }

        @JavascriptInterface
        public String activate(String l4, String token) {
            long w = lockLeft("act");
            if (w > 0) return "LOCKED:" + w;
            if (l4 == null || !l4.matches("\\d{4}")) return "BAD";
            if (same(norm(token), norm(tokenFor(devId(), l4)))) {
                prefs.edit().putString("l4", l4).putString("tk", norm(token)).apply();
                return "OK";
            }
            fail("act");
            return "BAD";
        }

        @JavascriptInterface
        public boolean adminCheck(String pin) {
            return pin != null && same(pin, ADMIN_PIN);
        }

        @JavascriptInterface
        public String makeToken(String pin, String l4, String dev) {
            long w = lockLeft("adm");
            if (w > 0) return "LOCKED:" + w;
            if (pin == null || !same(pin, ADMIN_PIN)) {
                fail("adm");
                return "ERR:PIN";
            }
            if (l4 == null || !l4.matches("\\d{4}")) return "ERR:L4";
            if (norm(dev).length() < 8) return "ERR:DEV";
            return "TOKEN:" + tokenFor(dev, l4);
        }

        @JavascriptInterface
        public String saveImage(String dataUrl, String name) {
            try {
                String b64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                name = name.replaceAll("[^A-Za-z0-9._-]", "_");
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (u == null) return "ERR";
                    try (OutputStream os = getContentResolver().openOutputStream(u)) {
                        os.write(bytes);
                    }
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    dir.mkdirs();
                    File f = new File(dir, name);
                    try (FileOutputStream os = new FileOutputStream(f)) {
                        os.write(bytes);
                    }
                    sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(f)));
                }
                return "OK";
            } catch (Throwable t) {
                return "ERR";
            }
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("bq", text));
            });
        }

        @JavascriptInterface
        public void openLink(final String url) {
            if (url == null || !url.matches("(?i)^https?://.+")) return;
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "লিংক খোলা যায়নি", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
